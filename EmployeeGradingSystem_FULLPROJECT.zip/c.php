<?php
include('configa.php');
 $q =" SELECT * FROM `loginTable` WHERE `grade`='c'";
 include('displayy.html');?> 