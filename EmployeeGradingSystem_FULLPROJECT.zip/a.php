<?php

include('configa.php');
 $q =" SELECT * FROM `loginTable` WHERE `grade`='a'";
 include('displayy.html');
?> 