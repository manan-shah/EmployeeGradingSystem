<?php
include('configa.php');
 $q =" SELECT * FROM `loginTable` WHERE `grade`='s'";
  include('displayy.html');
?> 