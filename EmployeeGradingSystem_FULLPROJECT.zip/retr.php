<?php
include('configa.php');
 $q =" SELECT * FROM `logintable` WHERE 1";
  include('displayy.html');
?> 