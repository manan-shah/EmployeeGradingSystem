<?php
include('configa.php');
 $q =" SELECT * FROM `loginTable` WHERE `grade`='b'";
 include('displayy.html');?> 